package Calculations;

public class Multiplication{

	
}
