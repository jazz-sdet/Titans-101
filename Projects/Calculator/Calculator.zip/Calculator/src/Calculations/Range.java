package Calculations;

public class Range {
	/**
	 *  This class will help to have numbers in certain range
		TODO:
		Add 2 encapsulated instances int variables min and max
		Create public getter and setter methods
		Create a constructor with 2 int arguments and assign values to min and max
	 */
	
}
