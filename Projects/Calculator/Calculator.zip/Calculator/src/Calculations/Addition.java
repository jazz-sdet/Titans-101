package Calculations;

public class Addition {
	
}
