public class Employee {


    /*
    1- Create private instance variables for employee firstName, lastName, phoneNumber, email, employeeId, startDate,
    title, department)
    2- Create getter and setter for instance variables
    3- Create the constructor to set the value to the instance variables
    4- Create one method to create the employeeId length of 20. This employee id must have letters as well.

       */

    public Employee createEmployee(String firstName, String lastName, String email, String employeeId, String startDate, String title, String department){

    /*
    this method need to return Employee according to the parameter
    call the constructor inside this method.
     */
        return null;
    }

    public String generateEmployeeId(){

        /*
        this method needs to return the employeeId Length of 20 which includes numbers as well.
        EmployeeId structure must be length of 20 UUID
        Example: 61c49c2e-7dcd-11ea-bc55
         */
        return "";
    }
}
